// ชื่อ นามสกุล - ชื่อเล่น
// 6XXXXXXXX
// Lab02_1
// 204203 Sec 00B

package main

import (
	"strings"
	"math"
	// "fmt"
)

const fracLen = 7
const expLen = 8

const BASE uint8 = 2
const DEBUG = false

// from Lab01_2
const MAX_INT = 64
const DEC_PLACE = 128


func float16bitNormed(n float32) string {
	// expLen = 8, fracLen = 7
	var bias = int(pow(2,expLen-1) - 1) // bias = 127

	if DEBUG {println("Bias", bias)}
	var minNorm float64 = 0.0000001			// dummy value
	var maxNorm float64 = 5000000000000		// dummy value


	sign := "0"
	if n < 0 {
		n = -n
		sign = "1"
	}

	if (float64(n) > maxNorm) || (float64(n) < minNorm) {
		if DEBUG {println(n, "overflow")}
		return ""
	}


















	return sign + ""
}


func pow(x, y int) float64{
	return math.Pow(float64(x), float64(y))
}
//------------------------------------ Lab01_2
