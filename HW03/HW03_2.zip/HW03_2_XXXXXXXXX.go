// ชื่อ นามสกุล ชื่อเล่น
// 6XXXXXXXX
// LabYY_Z |  HWYY_Z
// 204203 Sec 00B

package main

import (
	"strings"
)

const MAX = 36 // really?

func baseNAddition(r1, r2 string, base int) string {
	//decPointPos1 := strings.Index(r1, ".")
	//decPointPos2 := strings.Index(r2, ".")




	return ""
}

