/*
* @Author: kk
* @Date:   2022-06-26 21:47:44
* @Last Modified by:   kk
* @Last Modified time: 2022-06-27 01:12:19
 */
package main

// import "strings"

func addNSubtract(n1, n2 string, bitLen uint8) (int64, int64) {

	return 0, 0
}
