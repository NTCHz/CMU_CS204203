#!/usr/bin/bash
# first_name last_name
# 6xxxxxxxx
# HW06_1
# 204203 Sec00B

local_maxima() {
   echo "$1"
}

# Main script
main() {
    result=$(local_maxima "$1")
    echo $result
}


# Execute main function if this script is run directly
if [ "$0" = "${BASH_SOURCE[0]}" ]; then
    while read -r line; do
        # echo $line
        line="${line%$'\n'}"
        [[ -n $line ]] && main "$line"
    done < /dev/stdin
fi