/*
* @Author: kk
* @Date:   2022-06-26 21:47:44
* @Last Modified by:   kk
* @Last Modified time: 2022-06-26 22:22:54
 */
package main

func twosComplToInt(x string) int64 {
	
	var result int64 = 0


	return result
}
