/*
* @Author: kk
* @Date:   2022-06-26 21:47:44
* @Last Modified by:   kk
* @Last Modified time: 2022-06-26 23:00:10
 */
package main

func additiveInverse(x string) (string, int64) {






	return "", 0
}

