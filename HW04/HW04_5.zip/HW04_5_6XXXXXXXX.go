package main


type Triplet struct {
	Offset int
	Length int
	Next   byte
}

func encodeLZ77(windowSize int, bufferSize int, inputString string) []Triplet {
	var result []Triplet

	return result
}

