package main

type Triplet struct {
	Offset int
	Length int
	Next   byte
}

func decodeLZ77(matches []Triplet) string {
	decodedString := []byte{}

	return string(decodedString)
}
