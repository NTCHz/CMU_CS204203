package main

import ( 
	"strings"
)

func decodeHuffman(encodedText string, codingTable map[string]string) string {
	var decoded strings.Builder


	return decoded.String()
}
